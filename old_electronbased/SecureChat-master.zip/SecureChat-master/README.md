# SecureChat

** a cybersecutirity project **

This is a minimal secure chat application powered by node.js
