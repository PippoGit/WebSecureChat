var net = require('net');
var emitter = require('events');

var client = net.connect({port: 2972}, function() {
  console.log('connected to server!');

  var me = {
    username: "pippo",
    pkey: "asdaDddaskadskdmk"
  };

  var message = {
    action: "login",
    msg: JSON.stringify(me),
    certificate: "certificato"
  };

  client.write(JSON.stringify(message));
});

client.on('data', function(data) {
   console.log(data.toString());
   //client.end();
});

client.on('end', function() {
   console.log('disconnected from server');
});
