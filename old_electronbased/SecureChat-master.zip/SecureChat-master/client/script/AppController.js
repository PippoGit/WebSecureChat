const UIChatViewController  = require('./UIChatViewController.js');
const UILoginViewController = require('./UILoginViewController.js');
const UIAlertViewController = require('./UIAlertViewController.js');
const UIContactsViewController = require('./UIContactsViewController.js');
const SecureMessage = require("./SecureMessage.js");

var net = require('net');

function AppController() {
  this.settings = require('../settings.json');

  this.me = {
    username: "",

    // other: "",
    // otherPkey: "",

    pkey: "",
    serverKey: "",
    sessionKey: "",

    busy: 0,
    logged: 0,
  };

  this.chatView = new UIChatViewController(this);
  this.loginView = new UILoginViewController(this);
  this.alertView = new UIAlertViewController(this);
  this.contactView = new UIContactsViewController(this);

  this.currentView = this.loginView.DOMElement;
}

AppController.prototype.changeView = function(view) {
  this.currentView.style.display = "none";
  this.currentView = document.getElementById(view);
  this.currentView.style.display = "block";
};

AppController.prototype.startServerConnection = function() {
  this.serverConnection = net.connect({host:ac.settings.net.serverAddress, port: ac.settings.net.serverPort}, function() {
    console.log('connected to server!');

  });

  this.serverConnection.on('data', function(data) {
    if(SecureMessage.isClearTxt(data.toString())) {
      var secmsg = SecureMessage.parse(data.toString());
    }
    else {
      var secmsg = SecureMessage.decrypt(ac.me.serverSessionKey, data.toString());
    }

    var m = secmsg.message;

    switch(m.action) {
      case "list":
        // if(!secmsg.verify(ac.settings.security.serverPublic)) {
        //   ac.alertView.show("Alert", "You received an unauthorized list of users and public keys");
        //   return;
        // }

        ac.contactView.refreshList(m.list);
        break;

      case "close":
        if(!ac.me.busy) return;

        ac.me.busy = 0;
        ac.alertView.show(ac.chatView.recipient + " closed the connection", "The user closed the connection.");
        ac.chatView.closeChat();
        break;

      case "error":
        ac.alertView.show("Error from server", m.description);
        break;

      case "post":
        secmsg.decryptText(ac.me.chatSessionKey, secmsg.message.text)
        ac.chatView.addReceivedMessage(secmsg);
        break;

      case "grant":

        ac.me.logged = 1;
        ac.changeView("UIContactsView");
        ac.getContactsList();
        break;

      case "request":

        if(!secmsg.verify(ac.settings.security.serverPublic)) {
          ac.alertView.show("Alert", "You received an unauthorized chat request");
          return;
        }

        var r = confirm("New request from " + m.sender);
        var message;

        if (r == true) {
          ac.changeView("UIChatView");
          ac.chatView.newChat(m.sender);
          message = new SecureMessage({
            action: "accept",
            other: m.sender
          });

          ac.me.chatSessionKey = message.appendSessionKey(m.pkey);
          message.sign(ac.me.private);
          ac.me.busy = 1;
        }
        else {
          message = new SecureMessage({
            action: "decline",
            other: m.sender
          });
        }
        ac.serverConnection.write(message.encrypt(ac.me.serverSessionKey));
        break;

      case "accepted":
      if(!secmsg.verify(ac.settings.security.serverPublic)) {
          ac.alertView.show("Alert", "You received an unauthorized session key");
          return;
        }

        alert(m.username + " accepted your request!");
        ac.me.busy = 1;
        ac.me.chatSessionKey = secmsg.extractSessionKey(ac.me.private);
        ac.changeView("UIChatView");
        ac.chatView.newChat(m.username);
        break;

      case "declined":
        ac.alertView.show("Request declined", m.username + " declined your request.");
        break;
    }

     //serverConnection.end();
  });

  this.serverConnection.on('end', function() {
    console.log('disconnected from server');

    if(ac.me.logged) //if user logged out me is undefined
      ac.alertView.show("Connection Lost", "Connection lost with the server..."); //server went down...
  });
}

AppController.prototype.getContactsList = function() {
  var message = new SecureMessage({action: "list"});
  ac.serverConnection.write(message.encrypt(ac.me.serverSessionKey));
}

var ac = new AppController();
ac.startServerConnection();
