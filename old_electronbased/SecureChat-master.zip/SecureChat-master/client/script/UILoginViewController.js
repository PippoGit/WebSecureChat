const SecureMessage = require("./SecureMessage.js");

function UILoginViewController(delegate) {
  this.appController = delegate;
  this.DOMElement = document.getElementById('UILoginView');

  document.getElementById("UIButtonLoginView").addEventListener("click", function() {

    if(delegate.me.logged == 0) {
      delegate.startServerConnection();
    }

    delegate.me.username = document.getElementById("UITextUsernameView").value;
    delegate.me.pkey = document.getElementById("UIPublicKeyView").value;
    delegate.me.private = document.getElementById("UIPrivateKeyView").value;

    var message = new SecureMessage({
      action: "login",
      username: delegate.me.username
    });

    delegate.me.serverSessionKey = message.appendSessionKey(delegate.settings.security.serverPublic);
    message.sign(delegate.me.private);
    delegate.serverConnection.write(message.stringify());
  });
}

module.exports = UILoginViewController;
