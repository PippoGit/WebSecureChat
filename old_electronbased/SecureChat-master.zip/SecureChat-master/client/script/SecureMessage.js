const crypto = require('crypto');

const symmetricAlgorithm = 'aes-128-cbc';
const symmetricKeySize   = 16;
const hashAlgorithm      = 'SHA256';

var SecureMessage = function SecureMessage(msg, lastSent) {
  this.message = msg;
  this.signature = "";
}

SecureMessage.prototype.setID = function (num) {
  this.message.id = (num == -1)?Math.abs(crypto.randomBytes(4).readInt32BE(0)):(num+1);
}

//returns HEX of the encripted SecureMessage
SecureMessage.prototype.encrypt = function (k) {
  var cipher = crypto.createCipheriv(symmetricAlgorithm, Buffer.from(k.key,'hex'), Buffer.from(k.iv,'hex'));
  var encrypted = cipher.update(this.stringify());

  encrypted = Buffer.concat([encrypted, cipher.final()]);

  return encrypted.toString('hex');
}

SecureMessage.prototype.encryptText = function (k) {
  var cipher = crypto.createCipheriv(symmetricAlgorithm, Buffer.from(k.key,'hex'), Buffer.from(k.iv,'hex'));
  var encrypted = cipher.update(this.message.text);

  encrypted = Buffer.concat([encrypted, cipher.final()]);

  this.message.text = encrypted.toString('hex');
}

//returns decrypted SecureMessage from HEX ciphertext
SecureMessage.decrypt = function (k, ciphertext) {
  var decipher = crypto.createDecipheriv(symmetricAlgorithm, Buffer.from(k.key,'hex'), Buffer.from(k.iv,'hex'));
  var decrypted = decipher.update(new Buffer(ciphertext, 'hex'));

  decrypted = Buffer.concat([decrypted, decipher.final()]);

  return SecureMessage.parse(decrypted.toString());
}

SecureMessage.prototype.decryptText = function (k) {
  var decipher = crypto.createDecipheriv(symmetricAlgorithm, Buffer.from(k.key,'hex'), Buffer.from(k.iv,'hex'));
  var decrypted = decipher.update(new Buffer(this.message.text, 'hex'));

  decrypted = Buffer.concat([decrypted, decipher.final()]);
  this.message.text = decrypted.toString();
}

SecureMessage.prototype.sign = function (key) {
  const sign = crypto.createSign(hashAlgorithm);
  sign.update(JSON.stringify(this.message));
  this.signature = sign.sign(key, 'hex');
}


SecureMessage.prototype.verify = function (key) {
  const verify = crypto.createVerify(hashAlgorithm);
  verify.update(JSON.stringify(this.message));
  return verify.verify(key, this.signature, 'hex');
}

SecureMessage.prototype.stringify = function () {
  return JSON.stringify(this);
}

SecureMessage.parse = function (json) {
  var m = new SecureMessage();
  var parsed = JSON.parse(json);
  m.message = parsed.message;
  m.signature = parsed.signature;
  return m;
}

SecureMessage.getRandomBytes = function (size) {
  return crypto.randomBytes(size);
}

SecureMessage.prototype.extractSessionKey = function (key) {
  var temp = {
    key: this.message.sessionKey.key,
    iv: this.message.sessionKey.iv
  }
  temp.key = crypto.privateDecrypt(key, new Buffer(temp.key, 'hex')).toString('hex');
  return temp;
}

SecureMessage.prototype.appendSessionKey = function (key) {
  var temp = {
    key: crypto.randomBytes(symmetricKeySize).toString('hex'),
    iv: crypto.randomBytes(symmetricKeySize).toString('hex')
  }

  this.message.sessionKey = {
    key: crypto.publicEncrypt(key, new Buffer(temp.key, 'hex')).toString('hex'),
    iv: temp.iv
  };

  return temp;
}

SecureMessage.isClearTxt = function(msg) {
  try {
    JSON.parse(msg);
  } catch (e) {
    return false;
  }
  return true;
}

module.exports = SecureMessage;
