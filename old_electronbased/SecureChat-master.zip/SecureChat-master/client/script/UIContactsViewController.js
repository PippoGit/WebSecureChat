const SecureMessage = require("./SecureMessage.js");

function UIContactsViewController(delegate) {
  this.appController = delegate;
  this.contactsList = document.getElementById("UIContactsListView");
  this.DOMElement = document.getElementById('UIContactsView');

  document.getElementById("UIButtonRefreshContactsButtonView").addEventListener("click", function() {
    delegate.getContactsList();
  });

  document.getElementById("UIButtonLogOutButtonView").addEventListener("click", function() {
    delegate.serverConnection.end();
    delegate.me.logged = 0;
    delegate.changeView("UILoginView");
  });
}

UIContactsViewController.prototype.refreshList = function (list) {

  while (this.contactsList.firstChild) {
      this.contactsList.removeChild(this.contactsList.firstChild);
  }

  if(list==undefined) return;

  for(var i=0; i<list.length; i++) {
    this.addContact(list[i]);
  }

}

UIContactsViewController.prototype.addContact = function (contact) {

  var li = document.createElement("li");
  var span = document.createElement("span");
  span.className = "UIContactsListUsernameText";
  var spanaccess = document.createElement("span");
  var i = document.createElement("i");
  i.className = "fas fa-chevron-circle-right";
  spanaccess.appendChild(i);
  spanaccess.className="UIContactsListAccess";
  span.appendChild(document.createTextNode(contact));
  li.appendChild(span);
  li.appendChild(spanaccess);

  var ac = this.appController;
  li.addEventListener("click", function() {
    // ac.me.other = contact.username;
    // ac.me.otherPkey = contact.pkey;

    var message = new SecureMessage({
      action: "request",
      recipient: contact
    });

    ac.serverConnection.write(message.encrypt(ac.me.serverSessionKey));
  });

  this.contactsList.appendChild(li);
}

module.exports = UIContactsViewController;
